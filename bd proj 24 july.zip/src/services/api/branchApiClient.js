const { fetchJson } = require('../../utils/http');

class BranchApiClient {
  constructor(config) {
    this.config = config;
  }

  headers() {
    if (!this.config.token) {
      throw new Error('BRANCH_API_TOKEN is not configured');
    }

    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.config.token}`
    };
  }

  async getAllBranches() {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials`, {
      method: 'GET',
      headers: this.headers()
    });
  }

  async getBranchById(filialId) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/${filialId}`, {
      method: 'GET',
      headers: this.headers()
    });
  }

  async searchByAddressTt(addressTt) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/search/by-address-tt/${encodeURIComponent(addressTt)}`, {
      method: 'GET',
      headers: this.headers()
    });
  }

  async getBranchContacts(filialId) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/${filialId}/contacts`, {
      method: 'GET',
      headers: this.headers()
    });
  }

  async updateBranch(filialId, payload) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/${filialId}`, {
      method: 'PATCH',
      headers: this.headers(),
      body: JSON.stringify(payload)
    });
  }

  async createBranchContact(filialId, payload) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/${filialId}/contacts`, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify(payload)
    });
  }

  async getBranchContact(contactId) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/contacts/${contactId}`, {
      method: 'GET',
      headers: this.headers()
    });
  }

  async updateBranchContact(contactId, payload) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/contacts/${contactId}`, {
      method: 'PUT',
      headers: this.headers(),
      body: JSON.stringify(payload)
    });
  }

  async deleteBranchContact(contactId) {
    return fetchJson(`${this.config.baseUrl}/api/v1/partners/filials/contacts/${contactId}`, {
      method: 'DELETE',
      headers: this.headers()
    });
  }
}

module.exports = { BranchApiClient };
