const { searchBranches } = require('../../utils/branchSearch');
const { normalizeText } = require('../../utils/text');

const LEGAL_FORM_STOPWORDS = new Set([
  'ип',
  'индивидуальный',
  'предприниматель',
  'ооо',
  'ооо.',
  'зао',
  'пао',
  'ао',
  'оао',
  'общество',
  'ограниченной',
  'ответственностью'
]);

function tokenizeJurLico(value) {
  return normalizeText(value)
    .replace(/["'`«»()\[\],.]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .filter((token) => !LEGAL_FORM_STOPWORDS.has(token));
}

function normalizeJurLicoKey(value) {
  return tokenizeJurLico(value).join(' ');
}

function buildSimilarJurLicoKey(value) {
  const tokens = tokenizeJurLico(value);
  if (tokens.length < 2) return '';
  return tokens.slice(0, 2).join(' ');
}

class BranchService {
  constructor(apiClient) {
    this.apiClient = apiClient;
  }

  async findBranches(query) {
    const directResult = await this.tryDirectSearch(query);
    if (directResult.length) return directResult;

    const all = await this.apiClient.getAllBranches();
    return searchBranches(Array.isArray(all) ? all : [], query);
  }

  async tryDirectSearch(query) {
    try {
      const result = await this.apiClient.searchByAddressTt(query);
      if (Array.isArray(result)) return result;
      return result ? [result] : [];
    } catch {
      return [];
    }
  }

  async getBranch(branchId) {
    return this.apiClient.getBranchById(branchId);
  }

  async getBranchesWithoutAddressTt() {
    const all = await this.apiClient.getAllBranches();
    return (Array.isArray(all) ? all : [])
      .filter((branch) => !String(branch.iiko?.address_tt || '').trim())
      .sort((a, b) => Number(a.id) - Number(b.id));
  }

  async getDuplicateJurLicoGroups() {
    const allResult = await this.apiClient.getAllBranches();
    const all = Array.isArray(allResult) ? allResult : [];
    const groups = new Map();

    for (const branch of all) {
      const displayName = String(branch.jur_lico || '').trim();
      const key = normalizeJurLicoKey(displayName);
      if (!key) continue;

      if (!groups.has(key)) {
        groups.set(key, {
          key,
          displayName,
          branches: []
        });
      }

      groups.get(key).branches.push(branch);
    }

    return Array.from(groups.values())
      .filter((group) => group.branches.length > 1)
      .map((group) => ({
        ...group,
        branches: group.branches.sort((a, b) => Number(a.id) - Number(b.id))
      }))
      .sort((a, b) => b.branches.length - a.branches.length || a.displayName.localeCompare(b.displayName, 'ru'));
  }

  async getSimilarJurLicoGroups() {
    const allResult = await this.apiClient.getAllBranches();
    const all = Array.isArray(allResult) ? allResult : [];
    const groups = new Map();

    for (const branch of all) {
      const displayName = String(branch.jur_lico || '').trim();
      const key = buildSimilarJurLicoKey(displayName);
      const normalizedKey = normalizeJurLicoKey(displayName);
      if (!key || !normalizedKey) continue;

      if (!groups.has(key)) {
        groups.set(key, {
          key,
          displayName: displayName || key,
          branches: [],
          normalizedVariants: new Set()
        });
      }

      const group = groups.get(key);
      group.branches.push(branch);
      group.normalizedVariants.add(normalizedKey);
    }

    return Array.from(groups.values())
      .filter((group) => group.branches.length > 1 && group.normalizedVariants.size > 1)
      .map((group) => ({
        key: group.key,
        displayName: group.displayName,
        branches: group.branches.sort((a, b) => Number(a.id) - Number(b.id)),
        variants: Array.from(group.normalizedVariants).sort((a, b) => a.localeCompare(b, 'ru'))
      }))
      .sort((a, b) => b.branches.length - a.branches.length || a.displayName.localeCompare(b.displayName, 'ru'));
  }

  async getContacts(branchId) {
    return this.apiClient.getBranchContacts(branchId);
  }

  async updateBranch(branchId, payload) {
    return this.apiClient.updateBranch(branchId, payload);
  }

  async createContact(branchId, payload) {
    return this.apiClient.createBranchContact(branchId, payload);
  }

  async getContact(contactId) {
    return this.apiClient.getBranchContact(contactId);
  }

  async updateContact(contactId, payload) {
    return this.apiClient.updateBranchContact(contactId, payload);
  }

  async deleteContact(contactId) {
    return this.apiClient.deleteBranchContact(contactId);
  }
}

module.exports = { BranchService };
