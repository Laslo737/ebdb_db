const { formatBranchCard, formatContacts, formatBranchList, formatDuplicateJurLicoGroups, formatSimilarJurLicoGroups } = require('./formatters');

const CONTACT_FIELDS = {
  contact_type: 'Тип контакта',
  fio: 'ФИО',
  phone: 'Телефон',
  telegram: 'Telegram',
  email: 'Email',
  yandex_messenger_login: 'Yandex Messenger login',
  email_yandex: 'Yandex email',
  birthday: 'Дата рождения',
  clothes_size: 'Размер одежды'
};

const CONTACT_FIELD_ORDER = Object.keys(CONTACT_FIELDS);
const CONTACT_PAYLOAD_FIELDS = [...CONTACT_FIELD_ORDER, 'tg_user_id', 'is_using_in_tg_bot'];
const CREATE_CONTACT_FIELD_ORDER = ['contact_type', 'fio', 'phone', 'telegram', 'email'];
const MAIN_MENU_BUTTONS = [
  { text: 'найти филиал' },
  { text: 'контакты' },
  { text: 'изменить контакт' },
  { text: 'добавить контакт' },
  { text: 'удалить контакт' },
  { text: 'проверки' },
  { text: 'меню' }
];
const BRANCH_ACTION_BUTTONS = [
  { text: 'контакты' },
  { text: 'изменить контакт' },
  { text: 'добавить контакт' },
  { text: 'удалить контакт' },
  { text: 'шаг назад' },
  { text: 'меню' }
];
const FLOW_CONTROL_BUTTONS = [
  { text: 'шаг назад' },
  { text: 'меню' }
];
const CONFIRM_BUTTONS = [
  { text: 'да' },
  { text: 'нет' },
  { text: 'шаг назад' },
  { text: 'меню' }
];
const CHECKS_MENU_BUTTONS = [
  { text: 'без iiko' },
  { text: 'дубли юр. лиц' },
  { text: 'похожие юр. лица' },
  { text: 'шаг назад' },
  { text: 'меню' }
];
const CHECKS_RESULT_LIMIT = 30;
const DUPLICATE_GROUPS_LIMIT = 20;
const SIMILAR_GROUPS_LIMIT = 20;

function getUserKey(event) {
  if (event.chat?.type === 'private') {
    return String(event.chat?.id || event.from?.login || event.from?.id || 'anonymous');
  }

  return String(event.chat?.id || event.from?.login || event.from?.id || 'anonymous');
}

function normalizeInput(value) {
  return String(value || '').trim();
}

function isCancel(text) {
  return /^(отмена|cancel|stop)$/i.test(normalizeInput(text));
}

function isStepBack(text) {
  return /^(шаг назад|назад|back)$/i.test(normalizeInput(text));
}

function isSkip(text) {
  return /^(-|пропустить|skip)$/i.test(normalizeInput(text));
}

function isClear(text) {
  return /^(-|очистить|clear)$/i.test(normalizeInput(text));
}

function buildContactPayload(contact) {
  const payload = {};
  for (const field of CONTACT_PAYLOAD_FIELDS) {
    if (field in (contact || {})) {
      payload[field] = contact[field] ?? null;
    }
  }
  return payload;
}

function sanitizeContactSelection(text) {
  return normalizeInput(text).replace(/^#/, '');
}

function countSearchTokens(value) {
  return normalizeInput(value)
    .replace(/[_\-]+/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
    .length;
}

function formatContactFields() {
  return CONTACT_FIELD_ORDER.map((field, index) => `${index + 1}. ${CONTACT_FIELDS[field]} (${field})`).join('\n');
}

function buildNumberButtons(items = [], limit = 9) {
  return items.slice(0, limit).map((_, index) => ({ text: String(index + 1) }));
}

function buildFieldButtons(fields = CONTACT_FIELD_ORDER) {
  return fields.map((field) => ({ text: field }));
}

class BotService {
  constructor({ branchService, sender, sessions }) {
    this.branchService = branchService;
    this.sender = sender;
    this.sessions = sessions;
  }

  async handleEvent(event) {
    if (event.type === 'system') return;
    if (!event.text?.trim()) {
      return this.sender.reply(event, {
        text: 'Сейчас я работаю только с текстом и кнопками. Нажмите кнопку ниже или напишите запрос на поиск филиала.'
      });
    }

    const text = event.text.trim();
    const userKey = getUserKey(event);
    const session = this.sessions.get(userKey);

    if (isCancel(text)) {
      this.sessions.clear(userKey);
      return this.sender.reply(event, {
        text: 'Готово, текущий сценарий отменен. Возвращаю в главное меню.',
        buttons: MAIN_MENU_BUTTONS
      });
    }

    if (/^(start|старт|help|помощь|menu|меню)$/i.test(text.replace(/^\//, ''))) {
      this.sessions.clear(userKey);
      return this.showHelp(event);
    }

    if (isStepBack(text)) {
      return this.handleStepBack(event, userKey, session);
    }

    if (session.flow) {
      return this.handleFlow(event, userKey, text, session.flow);
    }

    if (session.awaitingBranchSelection) {
      return this.handleBranchSelection(event, userKey, text, session);
    }

    if (session.awaitingCommandInput) {
      return this.handleAwaitingCommandInput(event, userKey, text, session.awaitingCommandInput);
    }

    if (/^(найти филиал|филиал|поиск)(?:\s|$)/i.test(text)) {
      return this.handleFindBranch(event, userKey, text);
    }

    if (/^контакты(?:\s|$)/i.test(text)) {
      return this.handleContactsShortcut(event, userKey, text);
    }

    if (/^изменить контакт(?:\s|$)/i.test(text)) {
      return this.startEditContact(event, userKey, text);
    }

    if (/^добавить контакт(?:\s|$)/i.test(text)) {
      return this.startAddContact(event, userKey, text);
    }

    if (/^удалить контакт(?:\s|$)/i.test(text)) {
      return this.startDeleteContact(event, userKey, text);
    }

    if (/^(проверки|проверка|контроль)(?:\s|$)/i.test(text)) {
      return this.showChecksMenu(event, userKey);
    }

    if (/^(без\s*iiko|без\s*address_tt|нет\s*iiko)(?:\s|$)/i.test(text)) {
      return this.showBranchesWithoutIiko(event, userKey);
    }

    if (/^(дубли\s*юр\.?\s*лиц|дубли\s*юрлиц|дубли\s*jur_lico)(?:\s|$)/i.test(text)) {
      return this.showDuplicateJurLico(event, userKey);
    }

    if (/^(похожие\s*юр\.?\s*лица|похожие\s*юрлица|похожие\s*jur_lico)(?:\s|$)/i.test(text)) {
      return this.showSimilarJurLico(event, userKey);
    }

    return this.sender.reply(event, {
      text: [
        'Не понял команду.',
        '',
        'Попробуйте один из вариантов:',
        '• нажмите кнопку ниже',
        '• напишите: филиал 1211',
        '• напишите адрес ТТ, например: Москва_15 Люб',
        '• напишите ФИО / юр. лицо, например: Коваленко Ольга',
        '• напишите: меню'
      ].join('\n'),
      buttons: MAIN_MENU_BUTTONS
    });
  }

  async handleFlow(event, userKey, text, flow) {
    if (flow.type === 'checks') {
      if (/^(без\s*iiko|без\s*address_tt|нет\s*iiko)(?:\s|$)/i.test(text)) {
        return this.showBranchesWithoutIiko(event, userKey);
      }

      if (/^(дубли\s*юр\.?\s*лиц|дубли\s*юрлиц|дубли\s*jur_lico)(?:\s|$)/i.test(text)) {
        return this.showDuplicateJurLico(event, userKey);
      }

      if (/^(похожие\s*юр\.?\s*лица|похожие\s*юрлица|похожие\s*jur_lico)(?:\s|$)/i.test(text)) {
        return this.showSimilarJurLico(event, userKey);
      }

      return this.sender.reply(event, {
        text: 'Выберите проверку кнопкой ниже.',
        buttons: CHECKS_MENU_BUTTONS
      });
    }

    if (flow.type === 'edit_contact') {
      if (flow.step === 'select_contact') return this.handleEditContactSelect(event, userKey, text, flow);
      if (flow.step === 'select_field') return this.handleEditContactField(event, userKey, text, flow);
      if (flow.step === 'enter_value') return this.handleEditContactValue(event, userKey, text, flow);
    }

    if (flow.type === 'add_contact') {
      return this.handleAddContactFlow(event, userKey, text, flow);
    }

    if (flow.type === 'delete_contact') {
      if (flow.step === 'select_contact') return this.handleDeleteContactSelect(event, userKey, text, flow);
      if (flow.step === 'confirm') return this.handleDeleteContactConfirm(event, userKey, text, flow);
    }

    return this.sender.reply(event, {
      text: 'Не получилось продолжить этот шаг. Попробуйте нажать кнопку ниже или напишите: шаг назад',
      buttons: FLOW_CONTROL_BUTTONS
    });
  }

  async handleStepBack(event, userKey, session) {
    if (session.flow?.type === 'edit_contact') {
      if (session.flow.step === 'select_contact') {
        this.sessions.patch(userKey, { flow: null });
        return this.sender.reply(event, { text: 'Возвращаюсь к действиям по филиалу.', buttons: BRANCH_ACTION_BUTTONS });
      }

      if (session.flow.step === 'select_field') {
        this.sessions.patch(userKey, {
          flow: {
            ...session.flow,
            step: 'select_contact',
            selectedContactId: undefined,
            selectedContact: undefined,
            selectedField: undefined
          }
        });

        const contacts = await this.branchService.getContacts(session.flow.branchId);
        return this.sender.reply(event, {
          text: [
            'Выберите контакт, который хотите изменить.',
            'Можно нажать кнопку с номером или написать id контакта.',
            '',
            formatContacts(contacts)
          ].join('\n'),
          buttons: [...buildNumberButtons(contacts), ...FLOW_CONTROL_BUTTONS]
        });
      }

      if (session.flow.step === 'enter_value') {
        const selected = session.flow.selectedContact || await this.branchService.getContact(session.flow.selectedContactId);
        this.sessions.patch(userKey, {
          flow: {
            ...session.flow,
            step: 'select_field',
            selectedContact: selected,
            selectedField: undefined
          }
        });

        return this.sender.reply(event, {
          text: [
            `Выбран контакт #${selected.id}.`,
            'Какое поле хотите изменить?',
            formatContactFields(),
            '',
            'Можно написать номер поля или его код, например: phone'
          ].join('\n'),
          buttons: [...buildFieldButtons(), ...FLOW_CONTROL_BUTTONS]
        });
      }
    }

    if (session.flow?.type === 'add_contact') {
      if ((session.flow.fieldIndex || 0) <= 0) {
        this.sessions.patch(userKey, { flow: null });
        return this.sender.reply(event, { text: 'Возвращаюсь к действиям по филиалу.', buttons: BRANCH_ACTION_BUTTONS });
      }

      const previousIndex = session.flow.fieldIndex - 1;
      const previousField = CREATE_CONTACT_FIELD_ORDER[previousIndex];
      const payload = { ...(session.flow.payload || {}) };
      delete payload[CREATE_CONTACT_FIELD_ORDER[session.flow.fieldIndex]];
      delete payload[previousField];

      this.sessions.patch(userKey, {
        flow: {
          ...session.flow,
          fieldIndex: previousIndex,
          payload
        }
      });

      return this.sender.reply(event, {
        text: `Введите значение для поля: ${CONTACT_FIELDS[previousField]}\nЕсли поле нужно пропустить, отправьте: -`,
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    if (session.flow?.type === 'delete_contact') {
      if (session.flow.step === 'select_contact') {
        this.sessions.patch(userKey, { flow: null });
        return this.sender.reply(event, { text: 'Возвращаюсь к действиям по филиалу.', buttons: BRANCH_ACTION_BUTTONS });
      }

      if (session.flow.step === 'confirm') {
        this.sessions.patch(userKey, {
          flow: {
            ...session.flow,
            step: 'select_contact',
            selectedContactId: undefined,
            selectedContact: undefined
          }
        });

        const contacts = await this.branchService.getContacts(session.flow.branchId);
        return this.sender.reply(event, {
          text: [
            'Выберите контакт, который хотите удалить.',
            'Можно нажать кнопку с номером или написать id контакта.',
            '',
            formatContacts(contacts)
          ].join('\n'),
          buttons: [...buildNumberButtons(contacts), ...FLOW_CONTROL_BUTTONS]
        });
      }
    }

    if (session.flow?.type === 'checks') {
      if (session.flow.step === 'result') {
        return this.showChecksMenu(event, userKey);
      }

      this.sessions.patch(userKey, { flow: null });
      return this.sender.reply(event, { text: 'Возвращаю в главное меню.', buttons: MAIN_MENU_BUTTONS });
    }

    if (session.awaitingBranchSelection || session.awaitingCommandInput) {
      this.sessions.patch(userKey, {
        awaitingBranchSelection: false,
        awaitingCommandInput: null,
        foundBranches: []
      });
      const buttons = session.selectedBranchId ? BRANCH_ACTION_BUTTONS : MAIN_MENU_BUTTONS;
      return this.sender.reply(event, { text: 'Этот шаг отменен. Возвращаю доступные действия.', buttons });
    }

    return this.sender.reply(event, { text: 'Сейчас некуда возвращаться. Можно выбрать действие в меню ниже.', buttons: MAIN_MENU_BUTTONS });
  }

  async showChecksMenu(event, userKey) {
    this.sessions.patch(userKey, {
      flow: {
        type: 'checks',
        step: 'menu'
      }
    });

    return this.sender.reply(event, {
      text: [
        'Раздел проверок.',
        '',
        'Сейчас доступно:',
        '• без iiko — показать филиалы, у которых не заполнен `iiko.address_tt`',
        '• дубли юр. лиц — строгие дубли по нормализованному `jur_lico`',
        '• похожие юр. лица — потенциально похожие записи по фамилии + имени',
        '',
        'Позже сюда можно добавить дубли филиалов и другие служебные выборки.'
      ].join('\n'),
      buttons: CHECKS_MENU_BUTTONS
    });
  }

  async showBranchesWithoutIiko(event, userKey) {
    const branches = await this.branchService.getBranchesWithoutAddressTt();
    this.sessions.patch(userKey, {
      flow: {
        type: 'checks',
        step: 'result',
        check: 'without_iiko'
      }
    });

    if (!branches.length) {
      return this.sender.reply(event, {
        text: 'Отлично: филиалов без `iiko.address_tt` не найдено.',
        buttons: CHECKS_MENU_BUTTONS
      });
    }

    const visible = branches.slice(0, CHECKS_RESULT_LIMIT);
    const hasMore = branches.length > visible.length;

    return this.sender.reply(event, {
      text: [
        `Нашел ${branches.length} филиалов без iiko/address_tt.`,
        hasMore ? `Показываю первые ${visible.length}.` : 'Показываю весь список.',
        '',
        formatBranchList(visible),
        '',
        'Можно нажать «шаг назад», чтобы вернуться к списку проверок.'
      ].join('\n'),
      buttons: CHECKS_MENU_BUTTONS
    });
  }

  async showDuplicateJurLico(event, userKey) {
    const groups = await this.branchService.getDuplicateJurLicoGroups();
    this.sessions.patch(userKey, {
      flow: {
        type: 'checks',
        step: 'result',
        check: 'duplicate_jur_lico'
      }
    });

    if (!groups.length) {
      return this.sender.reply(event, {
        text: 'Отлично: дублей по юр. лицам не найдено.',
        buttons: CHECKS_MENU_BUTTONS
      });
    }

    const visible = groups.slice(0, DUPLICATE_GROUPS_LIMIT);
    const hasMore = groups.length > visible.length;

    return this.sender.reply(event, {
      text: [
        `Нашел ${groups.length} групп дублей по юр. лицам.`,
        hasMore ? `Показываю первые ${visible.length} групп.` : 'Показываю все найденные группы.',
        '',
        formatDuplicateJurLicoGroups(visible),
        '',
        'Можно нажать «шаг назад», чтобы вернуться к списку проверок.'
      ].join('\n'),
      buttons: CHECKS_MENU_BUTTONS
    });
  }

  async showSimilarJurLico(event, userKey) {
    const groups = await this.branchService.getSimilarJurLicoGroups();
    this.sessions.patch(userKey, {
      flow: {
        type: 'checks',
        step: 'result',
        check: 'similar_jur_lico'
      }
    });

    if (!groups.length) {
      return this.sender.reply(event, {
        text: 'Похожих юр. лиц не найдено.',
        buttons: CHECKS_MENU_BUTTONS
      });
    }

    const visible = groups.slice(0, SIMILAR_GROUPS_LIMIT);
    const hasMore = groups.length > visible.length;

    return this.sender.reply(event, {
      text: [
        `Нашел ${groups.length} групп похожих юр. лиц.`,
        hasMore ? `Показываю первые ${visible.length} групп.` : 'Показываю все найденные группы.',
        '',
        formatSimilarJurLicoGroups(visible),
        '',
        'Это не строгие дубли, а кандидаты на ручную проверку.',
        'Можно нажать «шаг назад», чтобы вернуться к списку проверок.'
      ].join('\n'),
      buttons: CHECKS_MENU_BUTTONS
    });
  }

  async showHelp(event) {
    return this.sender.reply(event, {
      text: [
        'Привет! Я помогу найти филиал и работать с его контактами.',
        '',
        'Что можно сделать через кнопки ниже:',
        '• найти филиал',
        '• посмотреть контакты',
        '• изменить контакт',
        '• добавить контакт',
        '• удалить контакт',
        '• открыть раздел проверок',
        '',
        'Как искать филиал:',
        '• по адресу ТТ — например: Москва_15 Люб',
        '• по юр. лицу / ФИО — например: Коваленко Ольга',
        '• по id филиала — например: 1211',
        '',
        'Полезно знать:',
        '• если найдется несколько филиалов, я покажу список и кнопки выбора',
        '• чтобы вернуться на шаг назад, напишите: шаг назад',
        '• чтобы вернуться в главное меню, напишите: меню'
      ].join('\n'),
      buttons: MAIN_MENU_BUTTONS
    });
  }

  async handleAwaitingCommandInput(event, userKey, text, awaiting) {
    this.sessions.patch(userKey, { awaitingCommandInput: null });

    if (awaiting.type === 'find_branch') {
      return this.handleFindBranch(event, userKey, `найти филиал ${text}`);
    }

    if (awaiting.type === 'contacts') {
      return this.handleContactsShortcut(event, userKey, `контакты ${text}`);
    }

    if (awaiting.type === 'edit_contact') {
      return this.startEditContact(event, userKey, `изменить контакт ${text}`);
    }

    if (awaiting.type === 'add_contact') {
      return this.startAddContact(event, userKey, `добавить контакт ${text}`);
    }

    if (awaiting.type === 'delete_contact') {
      return this.startDeleteContact(event, userKey, `удалить контакт ${text}`);
    }

    return this.showHelp(event);
  }

  async handleFindBranch(event, userKey, text) {
    const query = text.replace(/^(найти филиал|филиал|поиск)\s*/i, '').trim();
    if (!query) {
      this.sessions.patch(userKey, {
        awaitingCommandInput: { type: 'find_branch' }
      });
      return this.sender.reply(event, {
        text: 'Введите адрес ТТ или юр. лицо. Например: Москва_15 Люб или Коваленко Ольга',
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    this.sessions.patch(userKey, { awaitingCommandInput: null });

    const branches = await this.branchService.findBranches(query);
    if (!branches.length) {
      this.sessions.clear(userKey);
      return this.sender.reply(event, { text: `По запросу «${query}» ничего не нашлось. Попробуйте адрес ТТ, id филиала или ФИО / юр. лицо.` });
    }

    if (branches.length >= 10 && countSearchTokens(query) < 2) {
      this.sessions.clear(userKey);
      return this.sender.reply(event, {
        text: [
          `Запрос «${query}» слишком общий, найдено слишком много совпадений.`,
          'Пожалуйста, уточните поиск.',
          '',
          'Можно указать:',
          '• фамилию + имя',
          '• адрес ТТ',
          '• id филиала'
        ].join('\n'),
        buttons: MAIN_MENU_BUTTONS
      });
    }

    if (branches.length === 1) {
      const branch = branches[0];
      this.sessions.patch(userKey, { selectedBranchId: branch.id, selectedBranchQuery: query });
      return this.sender.reply(event, {
        text: [
          'Нашел филиал:',
          formatBranchCard(branch),
          '',
          'Что можно сделать дальше: посмотреть контакты, изменить контакт, добавить контакт или удалить контакт.',
          'Можно нажать кнопку ниже.'
        ].join('\n'),
        buttons: BRANCH_ACTION_BUTTONS
      });
    }

    this.sessions.patch(userKey, {
      awaitingBranchSelection: true,
      foundBranches: branches.map((branch) => ({ id: branch.id })),
      selectedBranchQuery: query
    });

    return this.sender.reply(event, {
      text: [
        `Нашлось ${branches.length} филиалов по запросу: ${query}`,
        'Показываю найденные варианты ниже.',
        'Напишите номер из списка или id филиала:',
        '',
        formatBranchList(branches)
      ].join('\n'),
      buttons: [...buildNumberButtons(branches), ...FLOW_CONTROL_BUTTONS]
    });
  }

  async handleBranchSelection(event, userKey, text, session) {
    const branches = await Promise.all((session.foundBranches || []).map(async ({ id }) => this.branchService.getBranch(id)));
    const byIndex = Number(text);
    let selected = null;

    if (Number.isInteger(byIndex) && byIndex >= 1 && byIndex <= branches.length) {
      selected = branches[byIndex - 1];
    } else {
      selected = branches.find((branch) => String(branch.id) === text.trim());
    }

    if (!selected) {
      return this.sender.reply(event, {
        text: 'Не удалось распознать выбор. Нажмите кнопку с номером или напишите id филиала.',
        buttons: [...buildNumberButtons(branches), ...FLOW_CONTROL_BUTTONS]
      });
    }

    this.sessions.patch(userKey, {
      awaitingBranchSelection: false,
      foundBranches: [],
      selectedBranchId: selected.id
    });

    return this.sender.reply(event, {
      text: [
        'Выбран филиал:',
        formatBranchCard(selected),
        '',
        'Что делаем дальше? Можно открыть контакты, изменить контакт, добавить контакт или удалить контакт.',
        'Нажмите кнопку ниже.'
      ].join('\n'),
      buttons: BRANCH_ACTION_BUTTONS
    });
  }

  async handleContactsShortcut(event, userKey, text) {
    const session = this.sessions.get(userKey);
    const query = text.replace(/^контакты\s*/i, '').trim();

    if (!query && !session.selectedBranchId) {
      this.sessions.patch(userKey, {
        awaitingCommandInput: { type: 'contacts' }
      });
      return this.sender.reply(event, {
        text: 'Напишите адрес ТТ, id филиала или юр. лицо, чтобы показать контакты. Например: Москва_15 Люб или Коваленко Ольга',
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    this.sessions.patch(userKey, { awaitingCommandInput: null });

    let branchId = session.selectedBranchId;
    if (query) {
      const branches = await this.branchService.findBranches(query);
      if (!branches.length) {
        return this.sender.reply(event, { text: `Не нашел филиал для показа контактов по запросу «${query}».` });
      }
      branchId = branches[0].id;
      this.sessions.patch(userKey, { selectedBranchId: branchId, selectedBranchQuery: query });
    }

    if (!branchId) {
      return this.sender.reply(event, {
        text: 'Сначала выберите филиал: нажмите «найти филиал» или напишите адрес ТТ, id филиала или ФИО / юр. лицо.'
      });
    }

    const [branch, contacts] = await Promise.all([
      this.branchService.getBranch(branchId),
      this.branchService.getContacts(branchId)
    ]);

    return this.sender.reply(event, {
      text: [
        formatBranchCard(branch),
        '',
        'Контакты:',
        formatContacts(Array.isArray(contacts) ? contacts : [])
      ].join('\n'),
      buttons: BRANCH_ACTION_BUTTONS
    });
  }

  async resolveBranchForCommand(userKey, rawQuery) {
    const query = rawQuery.trim();
    const session = this.sessions.get(userKey);

    if (!query) {
      return session.selectedBranchId ? { branchId: session.selectedBranchId } : { error: 'Сначала выберите филиал: нажмите «найти филиал» или напишите адрес ТТ, id филиала или ФИО / юр. лицо.' };
    }

    this.sessions.patch(userKey, { awaitingCommandInput: null });

    const branches = await this.branchService.findBranches(query);
    if (!branches.length) {
      return { error: `Не нашел филиал по запросу «${query}». Попробуйте адрес ТТ, id филиала или ФИО / юр. лицо.` };
    }

    if (branches.length >= 10 && countSearchTokens(query) < 2) {
      return {
        error: [
          `Запрос «${query}» слишком общий, найдено слишком много совпадений.`,
          'Уточните фамилию + имя, адрес ТТ или id филиала.'
        ].join('\n')
      };
    }

    return { branchId: branches[0].id, query };
  }

  async startEditContact(event, userKey, text) {
    const query = text.replace(/^изменить контакт\s*/i, '');
    if (!query && !this.sessions.get(userKey).selectedBranchId) {
      this.sessions.patch(userKey, {
        awaitingCommandInput: { type: 'edit_contact' }
      });
      return this.sender.reply(event, {
        text: 'Напишите адрес ТТ, id филиала или юр. лицо, для которого нужно изменить контакт.',
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    const resolved = await this.resolveBranchForCommand(userKey, query);
    if (resolved.error) return this.sender.reply(event, { text: resolved.error });

    const branchId = resolved.branchId;
    const contacts = await this.branchService.getContacts(branchId);
    if (!Array.isArray(contacts) || !contacts.length) {
      return this.sender.reply(event, { text: 'У этого филиала пока нет контактов, которые можно изменить.' });
    }

    this.sessions.patch(userKey, {
      selectedBranchId: branchId,
      flow: {
        type: 'edit_contact',
        step: 'select_contact',
        branchId,
        contacts: contacts.map((contact) => ({
          id: contact.id,
          contact_type: contact.contact_type,
          fio: contact.fio,
          phone: contact.phone,
          telegram: contact.telegram,
          email: contact.email,
          yandex_messenger_login: contact.yandex_messenger_login,
          email_yandex: contact.email_yandex,
          birthday: contact.birthday,
          clothes_size: contact.clothes_size,
          tg_user_id: contact.tg_user_id,
          is_using_in_tg_bot: contact.is_using_in_tg_bot
        }))
      }
    });

    return this.sender.reply(event, {
      text: [
        'Выберите контакт, который хотите изменить.',
        'Можно нажать кнопку с номером или написать id контакта.',
        '',
        formatContacts(contacts)
      ].join('\n'),
      buttons: [...buildNumberButtons(contacts), ...FLOW_CONTROL_BUTTONS]
    });
  }

  async handleEditContactSelect(event, userKey, text, flow) {
    const existing = Array.isArray(flow.contacts) ? flow.contacts.filter(Boolean) : [];
    const normalizedText = sanitizeContactSelection(text);
    const byIndex = Number(normalizedText);
    let selected = null;

    if (Number.isInteger(byIndex) && byIndex >= 1 && byIndex <= existing.length) {
      selected = existing[byIndex - 1];
    } else {
      selected = existing.find((contact) => String(contact.id) === normalizedText);
    }

    if (!selected) {
      return this.sender.reply(event, {
        text: 'Не удалось распознать контакт. Нажмите кнопку с номером или напишите id контакта.',
        buttons: [...buildNumberButtons(existing), ...FLOW_CONTROL_BUTTONS]
      });
    }

    this.sessions.patch(userKey, {
      flow: {
        ...flow,
        step: 'select_field',
        selectedContactId: selected.id,
        selectedContact: selected
      }
    });

    return this.sender.reply(event, {
      text: [
        `Выбран контакт #${selected.id}.`,
        'Какое поле хотите изменить?',
        formatContactFields(),
        '',
        'Можно написать номер поля или его код, например: phone'
      ].join('\n'),
      buttons: [...buildFieldButtons(), ...FLOW_CONTROL_BUTTONS]
    });
  }

  async handleEditContactField(event, userKey, text, flow) {
    const byIndex = Number(text);
    let field = null;

    if (Number.isInteger(byIndex) && byIndex >= 1 && byIndex <= CONTACT_FIELD_ORDER.length) {
      field = CONTACT_FIELD_ORDER[byIndex - 1];
    } else {
      field = CONTACT_FIELD_ORDER.find((item) => item.toLowerCase() === text.trim().toLowerCase());
    }

    if (!field) {
      return this.sender.reply(event, {
        text: 'Не удалось распознать поле. Напишите номер поля или его код, например: phone',
        buttons: [...buildFieldButtons(), ...FLOW_CONTROL_BUTTONS]
      });
    }

    this.sessions.patch(userKey, {
      flow: {
        ...flow,
        step: 'enter_value',
        selectedField: field
      }
    });

    const currentValue = flow.selectedContact?.[field] ?? 'не заполнено';
    return this.sender.reply(event, {
      text: [
        `Поле: ${CONTACT_FIELDS[field]}`,
        `Текущее значение: ${currentValue}`,
        'Введите новое значение.',
        'Если поле нужно очистить, отправьте: -'
      ].join('\n'),
      buttons: [{ text: '-' }, ...FLOW_CONTROL_BUTTONS]
    });
  }

  async handleEditContactValue(event, userKey, text, flow) {
    const field = flow.selectedField;
    const currentContact = flow.selectedContact || await this.branchService.getContact(flow.selectedContactId);
    const payload = buildContactPayload(currentContact);
    payload[field] = isClear(text) ? null : normalizeInput(text);

    const updated = await this.branchService.updateContact(flow.selectedContactId, payload);
    this.sessions.patch(userKey, {
      flow: null
    });

    return this.sender.reply(event, {
      text: [
        'Готово, контакт обновлен.',
        '',
        formatContacts([updated])
      ].join('\n'),
      buttons: BRANCH_ACTION_BUTTONS
    });
  }

  async startAddContact(event, userKey, text) {
    const query = text.replace(/^добавить контакт\s*/i, '');
    if (!query && !this.sessions.get(userKey).selectedBranchId) {
      this.sessions.patch(userKey, {
        awaitingCommandInput: { type: 'add_contact' }
      });
      return this.sender.reply(event, {
        text: 'Напишите адрес ТТ, id филиала или юр. лицо, для которого нужно добавить контакт.',
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    const resolved = await this.resolveBranchForCommand(userKey, query);
    if (resolved.error) return this.sender.reply(event, { text: resolved.error });

    const branchId = resolved.branchId;
    this.sessions.patch(userKey, {
      selectedBranchId: branchId,
      flow: {
        type: 'add_contact',
        step: 'enter_value',
        branchId,
        fieldIndex: 0,
        payload: {}
      }
    });

    return this.sender.reply(event, {
      text: [
        'Начинаем добавление нового контакта.',
        `Введите значение для поля: ${CONTACT_FIELDS[CREATE_CONTACT_FIELD_ORDER[0]]}`,
        'Если поле не нужно заполнять, отправьте: -',
        'Чтобы вернуться на шаг назад, напишите: шаг назад'
      ].join('\n'),
      buttons: FLOW_CONTROL_BUTTONS
    });
  }

  async handleAddContactFlow(event, userKey, text, flow) {
    const field = CREATE_CONTACT_FIELD_ORDER[flow.fieldIndex];
    const payload = { ...(flow.payload || {}) };

    if (!isSkip(text)) {
      payload[field] = normalizeInput(text);
    }

    const nextIndex = flow.fieldIndex + 1;
    if (nextIndex >= CREATE_CONTACT_FIELD_ORDER.length) {
      const created = await this.branchService.createContact(flow.branchId, payload);
      this.sessions.patch(userKey, { flow: null });
      return this.sender.reply(event, {
        text: [
          'Готово, контакт создан.',
          '',
          formatContacts([created])
        ].join('\n'),
        buttons: BRANCH_ACTION_BUTTONS
      });
    }

    const nextField = CREATE_CONTACT_FIELD_ORDER[nextIndex];
    this.sessions.patch(userKey, {
      flow: {
        ...flow,
        fieldIndex: nextIndex,
        payload
      }
    });

    return this.sender.reply(event, {
      text: `Введите значение для поля: ${CONTACT_FIELDS[nextField]}\nЕсли поле не нужно заполнять, отправьте: -`,
      buttons: FLOW_CONTROL_BUTTONS
    });
  }

  async startDeleteContact(event, userKey, text) {
    const query = text.replace(/^удалить контакт\s*/i, '');
    if (!query && !this.sessions.get(userKey).selectedBranchId) {
      this.sessions.patch(userKey, {
        awaitingCommandInput: { type: 'delete_contact' }
      });
      return this.sender.reply(event, {
        text: 'Напишите адрес ТТ, id филиала или юр. лицо, для которого нужно удалить контакт.',
        buttons: FLOW_CONTROL_BUTTONS
      });
    }

    const resolved = await this.resolveBranchForCommand(userKey, query);
    if (resolved.error) return this.sender.reply(event, { text: resolved.error });

    const branchId = resolved.branchId;
    const contacts = await this.branchService.getContacts(branchId);
    if (!Array.isArray(contacts) || !contacts.length) {
      return this.sender.reply(event, { text: 'У этого филиала нет контактов, которые можно удалить.' });
    }

    this.sessions.patch(userKey, {
      selectedBranchId: branchId,
      flow: {
        type: 'delete_contact',
        step: 'select_contact',
        branchId,
        contacts: contacts.map((contact) => ({
          id: contact.id,
          contact_type: contact.contact_type,
          fio: contact.fio,
          phone: contact.phone,
          telegram: contact.telegram,
          email: contact.email,
          yandex_messenger_login: contact.yandex_messenger_login,
          email_yandex: contact.email_yandex,
          birthday: contact.birthday,
          clothes_size: contact.clothes_size,
          tg_user_id: contact.tg_user_id,
          is_using_in_tg_bot: contact.is_using_in_tg_bot
        }))
      }
    });

    return this.sender.reply(event, {
      text: [
        'Выберите контакт, который хотите удалить.',
        'Можно нажать кнопку с номером или написать id контакта.',
        '',
        formatContacts(contacts)
      ].join('\n'),
      buttons: [...buildNumberButtons(contacts), ...FLOW_CONTROL_BUTTONS]
    });
  }

  async handleDeleteContactSelect(event, userKey, text, flow) {
    const existing = Array.isArray(flow.contacts) ? flow.contacts.filter(Boolean) : [];
    const normalizedText = sanitizeContactSelection(text);
    const byIndex = Number(normalizedText);
    let selected = null;

    if (Number.isInteger(byIndex) && byIndex >= 1 && byIndex <= existing.length) {
      selected = existing[byIndex - 1];
    } else {
      selected = existing.find((contact) => String(contact.id) === normalizedText);
    }

    if (!selected) {
      return this.sender.reply(event, {
        text: 'Не удалось распознать контакт. Нажмите кнопку с номером или напишите id контакта.',
        buttons: [...buildNumberButtons(existing), ...FLOW_CONTROL_BUTTONS]
      });
    }

    this.sessions.patch(userKey, {
      flow: {
        ...flow,
        step: 'confirm',
        selectedContactId: selected.id,
        selectedContact: selected
      }
    });

    return this.sender.reply(event, {
      text: [
        'Подтвердите удаление контакта:',
        formatContacts([selected]),
        '',
        'Напишите «да» или «нет».'
      ].join('\n'),
      buttons: CONFIRM_BUTTONS
    });
  }

  async handleDeleteContactConfirm(event, userKey, text, flow) {
    if (/^(нет|no|n)$/i.test(normalizeInput(text))) {
      this.sessions.patch(userKey, { flow: null });
      return this.sender.reply(event, { text: 'Удаление отменено.', buttons: BRANCH_ACTION_BUTTONS });
    }

    if (!/^(да|yes|y)$/i.test(normalizeInput(text))) {
      return this.sender.reply(event, { text: 'Пожалуйста, ответьте: «да» или «нет».', buttons: CONFIRM_BUTTONS });
    }

    await this.branchService.deleteContact(flow.selectedContactId);
    this.sessions.patch(userKey, { flow: null });
    return this.sender.reply(event, { text: `Готово, контакт #${flow.selectedContactId} удален.`, buttons: BRANCH_ACTION_BUTTONS });
  }
}

module.exports = { BotService };
